# Info o projekte:
- Meno a priezvisko: <first_name_last_name>
- Názov projektu: <project_name>
- Link na repozitár: [<repo_link>](<repo_link>)
- Link na verejnú inštanciu projektu: [<hosting_link>](<hosting_link>)

# Info o reportovanej verzii:
- Tag: beta    <!-- Uviesť beta_cisloSubverzie, ak ste robili v bete zmeny pred termínom odovzdania -->

# Info k testovaniu:     
<!-- Uveďte credentials testovacích používateľov, ak sú potrebné na otestovanie Vašej bety. Uveďte aj akékoľvek iné relevantné informácie k testovaniu. Tieto informácie môžete alternatívne poslať aj e-mailom spolu s odovzdaním bety (napr. ak nechcete testovacie credentials zverejňovať). -->

# Postup, ako rozbehať vývojové prostredie 
<!-- Postup pre lokálne rozbehanie vývojového prostredia (kto si trúfa, kľudne ako Docker file / Docker compose) -->

# Stav implementácie:
<!-- V bodoch spísať, ktoré funcionality sú už implementované, rozpracované, neimplementované vôbec -->

# Časový plán:
<!-- Akutalizovaný časový plán na zvyšné obodobie do odovzdania finálnej verzie -->

# Problémy:
<!-- Popísať akékoľvek problémy, s ktorými ste sa stretli. Ak neboli žiadne, explicitne to uveďte. -->


