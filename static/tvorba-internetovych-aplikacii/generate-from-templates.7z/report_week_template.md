# Info o projekte:
- Meno a priezvisko: <first_name_last_name>
- Názov projektu: <project_name>
- Link na repozitár: [<repo_link>](<repo_link>)

# Info o reportovanej verzii:  
<!-- Upraviť podľa aktuálneho týždňa, reporty začínajú 4. týždeň semestra. Upraviť aj názov reportu. -->
- Tag: week<report_week>
- Obdobie: <report_week>. týždeň, <report_date_from> - <report_date_to> 

# Plán:
<!-- Skopírovať z predchádzajúceho reportu časť "Plán na ďalší týždeň" resp. pre prvý report z plánu zo špecifikácie -->

# Vykonaná práca:
<!-- Ku každému bodu je nutné priradiť číslo commitu, ktorý ho implementuje - samostatný commit pre každý bod! -->

# Zdôvodnenie rozdielov medzi plánom a vykonanou prácou:
<!-- Zdôvodniť nedokončenie všetkých bodov z plánu (napr. choroba, iné nečakané povinnosti, ...), ale aj predbehnutie plánu -->

# Plán na ďalší týždeň:
<!-- Skombinovať plán zo špecifikácie spolu s potenciálnym oneskorením / predbehnutím plánu v minulých týždňoch -->

# Problémy:
<!-- Popísať akékoľvek problémy, s ktorými ste sa stretli. Ak neboli žiadne, explicitne to uveďte. -->

# Zmeny v špecifikácii:
<!-- Popísať akékoľvek zmeny v špecifikácii, spolu s ich odôvodnením (netreba uvádzať iba zmeny v časovom pláne, nakoľko tie popisujete v predchádzajúcich bodoch). Cvičiaci má právo posúdiť vhodnosť týchto zmien a zaslať k nim spätnú väzbu na zapracovanie. Ak neboli žiadne zmeny, explicitne to uveďte.
 

