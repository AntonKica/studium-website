# Info o projekte:
- Meno a priezvisko: <first_name_last_name>
- Názov projektu: <project_name>
- Link na repozitár: [<repo_link>](<repo_link>)
- Link na verejnú inštanciu projektu: [<hosting_link>](<hosting_link>)

# Info o reportovanej verzii:
- Tag: final    <!-- Uviesť final_cisloSubverzie, ak ste robili vo finálnej verzii zmeny pred termínom odovzdania -->

# Info k testovaniu:     
<!-- Uveďte credentials testovacích používateľov, ak sú potrebné na otestovanie Vášho projektu. Uveďte aj akékoľvek iné relevantné informácie k testovaniu. Tieto informácie môžete alternatívne poslať aj e-mailom spolu s odovzdaním finálnej verzie (napr. ak nechcete testovacie credentials zverejňovať). -->

# Postup, ako rozbehať vývojové prostredie 
<!-- Postup pre lokálne rozbehanie vývojového prostredia (kto si trúfa, kľudne ako Docker file / Docker compose) -->

# Stav implementácie:
<!-- V bodoch spísať, ktoré funcionality sú už implementované, rozpracované, neimplementované vôbec -->

# Retrospektíva:
<!-- Keby ste to robili znovu, čo by ste urobili inak? -->
<!-- Ste hrdý na výsledky svojej práce? Ktorý aspekt projektu je podľa Vás najviac kvalitný? -->



